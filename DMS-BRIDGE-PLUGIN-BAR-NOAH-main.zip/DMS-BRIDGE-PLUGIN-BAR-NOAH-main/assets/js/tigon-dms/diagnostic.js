jQuery(document).ready(() => {
    jQuery(".body").attr('style', "display:flex;");
});